import os
import re
import numpy as np
import streamlit as st
from pypdf import PdfReader
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()
st.set_page_config(page_title="AskMyPDF", page_icon="📄", layout="wide")
st.title("📄 AskMyPDF")
st.caption("A small Retrieval-Augmented Generation (RAG) demo. Answers are grounded in your uploaded PDF.")

@st.cache_resource
def load_embedder():
    return SentenceTransformer("all-MiniLM-L6-v2")

def extract_pages(pdf_file):
    reader = PdfReader(pdf_file)
    pages = []
    for page_no, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        if text.strip():
            pages.append({"page": page_no, "text": text})
    return pages

def make_chunks(pages, chunk_words=180, overlap=35):
    chunks = []
    for item in pages:
        words = re.sub(r"\s+", " ", item["text"]).split()
        step = max(1, chunk_words - overlap)
        for start in range(0, len(words), step):
            part = " ".join(words[start:start + chunk_words])
            if len(part) > 40:
                chunks.append({"page": item["page"], "text": part})
    return chunks

def retrieve(question, chunks, model, top_k=4):
    corpus = [c["text"] for c in chunks]
    vectors = model.encode(corpus, normalize_embeddings=True)
    q_vec = model.encode([question], normalize_embeddings=True)[0]
    scores = np.dot(vectors, q_vec)
    indices = np.argsort(scores)[::-1][:top_k]
    return [{**chunks[i], "score": float(scores[i])} for i in indices]

def generate_answer(question, matches):
    api_key = os.getenv("GEMINI_API_KEY")
    if not api_key:
        return ("No Gemini API key configured. Here are the most relevant passages. "
                "Add GEMINI_API_KEY to a .env file to enable generated answers.")
    try:
        from google import genai
        client = genai.Client(api_key=api_key)
        context = "\n\n".join(
            f"[Page {m['page']}]\n{m['text']}" for m in matches
        )
        prompt = f"""Answer the question using ONLY the context below.
If the answer is not present, say you cannot find it in this document.
Cite page numbers in your answer.

CONTEXT:
{context}

QUESTION: {question}"""
        response = client.models.generate_content(
            model=os.getenv("GEMINI_MODEL", "gemini-2.0-flash"),
            contents=prompt
        )
        return response.text or "The model returned an empty response."
    except Exception as exc:
        return f"Gemini request failed: {exc}. You can still inspect the retrieved passages below."

uploaded = st.file_uploader("Upload a text-based PDF", type=["pdf"])
if uploaded:
    with st.spinner("Reading and indexing the PDF… (first run downloads the embedding model)"):
        pages = extract_pages(uploaded)
        chunks = make_chunks(pages)
        embedder = load_embedder()
    st.success(f"Indexed {len(chunks)} text chunks from {len(pages)} pages.")
    question = st.text_input("Ask a question about this document")
    if st.button("Find answer", type="primary", disabled=not question.strip()):
        with st.spinner("Retrieving relevant passages and preparing an answer…"):
            matches = retrieve(question, chunks, embedder)
            answer = generate_answer(question, matches)
        st.subheader("Answer")
        st.write(answer)
        st.subheader("Retrieved sources")
        for m in matches:
            with st.expander(f"Page {m['page']} · similarity {m['score']:.3f}"):
                st.write(m["text"])
else:
    st.info("Upload a PDF to begin. Scanned PDFs may need OCR before text can be extracted.")
