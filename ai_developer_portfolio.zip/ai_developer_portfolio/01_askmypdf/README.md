# AskMyPDF — RAG Document Assistant

Upload a PDF, retrieve relevant passages using semantic similarity, and ask questions grounded in the document.

## Run

```bash
pip install -r requirements.txt
# Optional: copy .env.example to .env and add a Gemini API key
streamlit run app.py
```

On first run, Sentence Transformers downloads the `all-MiniLM-L6-v2` embedding model. Without a Gemini key, the app shows the most relevant retrieved passages instead of generating an LLM answer.

## AI concepts

- PDF text extraction
- Chunking with overlap
- Dense vector embeddings
- Cosine-similarity retrieval
- Retrieval-grounded generation (RAG)
- Source passage display to help verify answers

## Next improvements

Add persistent vector storage, OCR for scanned PDFs, multi-file collections, retrieval evaluation (Recall@k / MRR), authentication, and a FastAPI backend.
