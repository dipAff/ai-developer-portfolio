# Smart Support Ticket Triage

A lightweight NLP system that classifies incoming support messages into a team queue, estimates confidence, and assigns a simple urgency label.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## What it demonstrates

- Text cleaning and TF-IDF vectorization
- Supervised multi-class text classification
- Train/test evaluation with a classification report
- Confidence-aware predictions
- Simple business routing rules

## Next improvements

Collect and label real anonymized tickets, compare Linear SVM / Logistic Regression, tune thresholds, add human review for low-confidence cases, monitor drift, and expose predictions through FastAPI.
