import re
import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report

st.set_page_config(page_title="Support Ticket Triage", page_icon="🎫")
st.title("🎫 Smart Support Ticket Triage")
st.caption("Classify support messages and route them to the most relevant team.")

TRAINING = [
    ("I was charged twice for my subscription", "Billing"),
    ("Please refund the payment from yesterday", "Billing"),
    ("My invoice has the wrong amount", "Billing"),
    ("I cannot update my card details", "Billing"),
    ("The payment failed but money was deducted", "Billing"),
    ("I need a copy of my monthly invoice", "Billing"),
    ("The mobile app crashes when I open it", "Technical"),
    ("I get an error while logging into my account", "Technical"),
    ("The dashboard is loading very slowly", "Technical"),
    ("The website shows a blank screen", "Technical"),
    ("My password reset link does not work", "Technical"),
    ("The application is not syncing my data", "Technical"),
    ("How can I change my delivery address", "Account"),
    ("Please help me update my profile name", "Account"),
    ("I want to delete my account", "Account"),
    ("How do I change my email address", "Account"),
    ("I cannot access my account settings", "Account"),
    ("Please explain how to enable two factor login", "Account"),
    ("My order has not arrived yet", "Orders"),
    ("I received the wrong product", "Orders"),
    ("Can I track my shipment", "Orders"),
    ("I want to cancel my recent order", "Orders"),
    ("The package arrived damaged", "Orders"),
    ("Please change the size of my order", "Orders"),
]
df = pd.DataFrame(TRAINING, columns=["text", "team"])
X_train, X_test, y_train, y_test = train_test_split(
    df.text, df.team, test_size=0.25, random_state=7, stratify=df.team
)
model = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2), stop_words="english",
                              lowercase=True, strip_accents="unicode")),
    ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
])
model.fit(X_train, y_train)
pred = model.predict(X_test)
accuracy = accuracy_score(y_test, pred)

st.metric("Held-out demo accuracy", f"{accuracy:.1%}")
st.caption("Small illustrative dataset: this metric is not evidence of production accuracy.")
st.subheader("Classify a new ticket")
ticket = st.text_area("Customer message", placeholder="Example: I was charged twice and need a refund…", height=120)
if st.button("Classify ticket", type="primary", disabled=not ticket.strip()):
    probabilities = model.predict_proba([ticket])[0]
    best_idx = probabilities.argmax()
    team = model.classes_[best_idx]
    confidence = float(probabilities[best_idx])
    urgent_terms = ["fraud", "security", "locked", "stolen", "urgent", "cannot access"]
    priority = "High" if any(term in ticket.lower() for term in urgent_terms) else "Normal"
    left, right = st.columns(2)
    left.metric("Suggested team", team)
    right.metric("Model confidence", f"{confidence:.1%}")
    st.write(f"**Suggested priority:** {priority}")
    if confidence < 0.45:
        st.warning("Low confidence: send this ticket for human review instead of auto-routing.")
    else:
        st.success("Suggested route generated. A human agent should confirm before action.")
with st.expander("View model evaluation"):
    st.text(classification_report(y_test, pred, zero_division=0))
