# AI Developer Portfolio Projects

Three practical, portfolio-ready Python projects designed to demonstrate core AI/ML and LLM application skills.

## Projects

| Project | What it demonstrates | Main technologies |
|---|---|---|
| 1. AskMyPDF — RAG Document Assistant | Document ingestion, chunking, embeddings, semantic retrieval, grounded answers | Python, Streamlit, Sentence Transformers, Gemini API (optional) |
| 2. Customer Churn Intelligence | ML pipeline, train/test split, metrics, feature importance, prediction UI | pandas, scikit-learn, Streamlit |
| 3. Smart Support Ticket Triage | NLP preprocessing, TF-IDF, text classification, confidence, priority routing | scikit-learn, pandas, Streamlit |

## Quick start

Use Python 3.10 or 3.11.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

Each project has its own README and requirements file. Run each app from its folder:

```bash
cd 01_askmypdf
pip install -r requirements.txt
streamlit run app.py
```

```bash
cd 02_churn_intelligence
pip install -r requirements.txt
streamlit run app.py
```

```bash
cd 03_support_ticket_triage
pip install -r requirements.txt
streamlit run app.py
```

## Suggested GitHub presentation

Create one public repository per project, or keep this monorepo and pin it on your GitHub profile. Add screenshots, a short demo video, and a clear explanation of your contribution after you run and test each project.

## Important

These are working starter implementations, not claims of production deployment. Run them locally, test with your own sample data, inspect the results, and customize the interfaces before listing them on your CV. Never upload private documents, customer data, API keys, or secrets to GitHub.
