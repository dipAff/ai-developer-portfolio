# Customer Churn Intelligence

An end-to-end tabular ML demo that trains a churn classifier on a reproducible synthetic dataset and predicts churn risk for a sample customer.

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## What to discuss in an interview

- Why use a stratified train/test split?
- Why standardize numeric features?
- Why evaluate with precision, recall, F1, and ROC-AUC instead of accuracy alone?
- What does a false negative mean in churn prediction?
- Why is feature importance not proof of causation?

## Important limitation

The app generates synthetic data for demonstration. Do not present its scores as real business performance. Replace the generator with a properly licensed, documented dataset before making real-world claims.
