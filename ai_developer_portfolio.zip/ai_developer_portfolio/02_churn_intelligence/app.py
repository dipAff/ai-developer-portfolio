import streamlit as st
import pandas as pd
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix

st.set_page_config(page_title="Churn Intelligence", page_icon="📊", layout="wide")
st.title("📊 Customer Churn Intelligence")
st.caption("End-to-end classification demo using reproducible synthetic customer data.")

@st.cache_resource
def train_model():
    X, y = make_classification(
        n_samples=2500, n_features=6, n_informative=5, n_redundant=0,
        weights=[0.72, 0.28], class_sep=0.9, random_state=42
    )
    cols = ["monthly_spend", "tenure_months", "support_calls",
            "late_payments", "usage_score", "plan_changes"]
    df = pd.DataFrame(X, columns=cols)
    # Transform features into interpretable ranges for the demo.
    df["monthly_spend"] = (df["monthly_spend"] * 18 + 65).clip(5, 250)
    df["tenure_months"] = (df["tenure_months"] * 9 + 24).clip(1, 120)
    df["support_calls"] = (df["support_calls"] * 2 + 3).clip(0, 20)
    df["late_payments"] = (df["late_payments"] * 1.5 + 2).clip(0, 12)
    df["usage_score"] = (df["usage_score"] * 12 + 55).clip(0, 100)
    df["plan_changes"] = (df["plan_changes"] * 1.5 + 2).clip(0, 12)
    X_train, X_test, y_train, y_test = train_test_split(
        df, y, test_size=0.2, random_state=42, stratify=y
    )
    model = Pipeline([
        ("scale", StandardScaler()),
        ("classifier", LogisticRegression(max_iter=1000, class_weight="balanced"))
    ])
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    prob = model.predict_proba(X_test)[:, 1]
    metrics = {
        "Accuracy": accuracy_score(y_test, pred),
        "Precision": precision_score(y_test, pred, zero_division=0),
        "Recall": recall_score(y_test, pred, zero_division=0),
        "F1": f1_score(y_test, pred, zero_division=0),
        "ROC-AUC": roc_auc_score(y_test, prob)
    }
    return model, cols, metrics, confusion_matrix(y_test, pred)

model, features, metrics, cm = train_model()
st.subheader("Model evaluation")
cols = st.columns(5)
for col, (name, value) in zip(cols, metrics.items()):
    col.metric(name, f"{value:.3f}")
st.write("Confusion matrix (rows = actual, columns = predicted)")
st.dataframe(pd.DataFrame(cm, index=["Actual: stay", "Actual: churn"],
                          columns=["Predicted: stay", "Predicted: churn"]))

st.divider()
st.subheader("Predict churn risk for a customer")
with st.form("customer"):
    a, b, c = st.columns(3)
    spend = a.slider("Monthly spend", 5.0, 250.0, 75.0)
    tenure = b.slider("Tenure (months)", 1, 120, 24)
    calls = c.slider("Support calls", 0, 20, 3)
    d, e, f = st.columns(3)
    late = d.slider("Late payments", 0, 12, 1)
    usage = e.slider("Usage score", 0.0, 100.0, 65.0)
    changes = f.slider("Plan changes", 0, 12, 2)
    submitted = st.form_submit_button("Predict risk", type="primary")

if submitted:
    sample = pd.DataFrame([[spend, tenure, calls, late, usage, changes]], columns=features)
    risk = float(model.predict_proba(sample)[0, 1])
    st.metric("Estimated churn probability", f"{risk:.1%}")
    if risk >= 0.65:
        st.warning("High-risk demo prediction. Consider reviewing the customer's experience.")
    elif risk >= 0.35:
        st.info("Moderate-risk demo prediction. Monitor engagement and support needs.")
    else:
        st.success("Low-risk demo prediction.")
st.caption("Synthetic educational dataset only. Not validated for real customer decisions.")
